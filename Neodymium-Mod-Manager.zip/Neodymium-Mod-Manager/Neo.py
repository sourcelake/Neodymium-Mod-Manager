import curses
import os
import requests
import json
win = curses.initscr()

curses.curs_set(0)
curses.noecho()


cwd = os.getcwd()


categories = {
    "Mods":      0,
    "Resources": 1,
    "Shaders":   2,
    "0":         3,

    "Download":  4,
    "Delete":    5,
    "Rename":    6,
    "1":         7,
    "Change Parent Directory": 8,
    "Show   Parent Directory": 9,
    "Exit":      10,
}

pointer = 0


def raw_input(stdscr, r, c, prompt_string):
    curses.echo() 
    curses.curs_set(1)
    stdscr.addstr(r, c, prompt_string)
    stdscr.refresh()
    input = stdscr.getstr(r, c, 100)
    curses.noecho()
    curses.curs_set(0)
    return input.decode("utf-8")  #       ^^^^  reading input at next line  

def delete(file, type):
    
    folder = open(".txt", "r").read()
    

    if type == "resource" or type == "r":
        folder += "\\resourcepacks\\"
    elif type == "mod" or type == "m":
        folder += "\\mods\\"
    elif type == "shader" or type == "s":
        folder += "\\shaderpacks\\"
    else:
        return type + "doesn't exist."
    
    os.chdir(folder)
    if file not in os.listdir("."):
        return "file does not exist."
    os.system("del "+ file)
    os.chdir(cwd)
    return "Successfully Deleted"

def rename(file, newfile, type):
    
    folder = open(".txt", "r").read()
    

    if type == "resource" or type == "r":
        folder += "\\resourcepacks\\"
    elif type == "mod" or type == "m":
        folder += "\\mods\\"
    elif type == "shader" or type == "s":
        folder += "\\shaderpacks\\"
    else:
        return type + "doesn't exist."
    
    os.chdir(folder)
    if file not in os.listdir("."):
        return "file does not exist."
    fdata = open(file, "rb").read()
    os.system("del "+ file)
    open(newfile, "wb").write(fdata)
    os.chdir(cwd)
    return "Successfully Renamed"



def download(id, type):
    folder = open(".txt", "r").read()

    url = f"https://curseforge.com/api/v1/mods/{id}/files/{id}/download"

    r = requests.get(url, allow_redirects=True)
    redirect_end = r.url
    filename = redirect_end.split("/")[6]
    


    if type == "resource" or type == "r":
        folder += "\\resourcepacks\\"
    elif type == "mod" or type == "m":
        folder += "\\mods\\"
    elif type == "shader" or type == "s":
        folder += "\\shaderpacks\\"
    else:
        return type + "doesn't exist."
    
    
    cachedname = folder + filename

    open(cachedname, 'wb').write(r.content)
    try:
        json.loads(open(cachedname, "r").read())["statusCode"]
    except:
        return filename + " downloaded successfully!"
    
    os.system("del " + cachedname)
    return "file doesn't exist on curseforge."


def listfiles(type):
    sourcedir = os.getcwd()
    os.chdir(open(".txt","r").read()+type)
    listed = os.listdir(".")
    open("C:\\Users\\lake\\Documents\\mod-manager\\modlist.py", "w").write(str(listed))
    win.clear()
    listedleft = len(listed)
    page = 0
    k=0
    while listedleft > 16:
        page += 1
        for i in range(16):
            
            listedleft -= 1
            win.addstr(i, 0, listed[k])
            k += 1

        win.addstr(18, 0, "<<< Page "+str(page)+" >>>")

        e = win.getkey()
        if e == "a":
            if page == 1:
                continue
            page -= 2
            k -= 32
            listedleft += 32
        else:
            pass
        win.clear()
    
    page += 1
    for i in range(listedleft):
        
        win.addstr(i, 0, listed[k])
        win.addstr(18, 0, "<<< Page "+str(page)+" >>>")

        k += 1

    win.getch()
    win.clear()

    os.chdir(sourcedir)




while True:
    os.chdir(cwd)
    keys = list(categories.keys())
    items = list(categories.values())

    for i in range(len(keys)):
        try:
            int(keys[i])
            win.addstr(items[i], 0, " "*10)
            continue
        except:
            win.addstr(items[i], 0, keys[i]+str(" "*(len("Change Parent Directory") - len(keys[i]))) + ("  < " if i == pointer else ""))


    char = win.getkey()
    win.clear()
    if char == "w" and pointer != 0: 
        pointer -= 1
        try:
            int(keys[pointer])
            pointer -= 1
        except:
            pass
        
    if char == "s" and pointer != len(keys)-1: 
        pointer += 1
        try:
            int(keys[pointer])
            pointer += 1
        except:
            pass
    if char == "e":
        
        win.clear()
        if pointer == categories["Exit"]:
            break

        if pointer == categories["Mods"]:
            
            listfiles("mods")
            
        if pointer == categories["Resources"]:
            
            listfiles("resourcepacks")

        if pointer == categories["Shaders"]:
            
            listfiles("shaderpacks")

        if pointer == categories["Change Parent Directory"]:
            win.addstr(0, 0, "Directory: ")
            directory = raw_input(win, 0, 11, "")
            
            win.clear()
            try:
                os.chdir(directory)
                os.chdir(cwd)
                if not directory.endswith("\\"):
                    directory += "\\"
                open(".txt", "w").write(directory)
                win.addstr("Successfully changed + saved parent directory location.")
            except:
                win.addstr("Directory doesnt exist.")
            win.getch()
            win.clear()

        if pointer == categories["Show   Parent Directory"]:
            win.addstr(0, 0, "Current Parent Directory: ")
            win.addstr(1, 0, open(".txt", "r").read())
            win.getch()
            win.clear()



        if pointer == categories["Delete"]:
            
            win.clear()
            win.addstr(0, 0, "type \"back\" to go back")

            win.addstr(2, 0, "filename : ")
            id = raw_input(win, 2, 11, "")
            win.clear()

            if id == "back":
                pass
            else:
                win.addstr(0, 0, "file type: ")
                typ = raw_input(win, 0, 11, "")
                win.clear()
                win.clear()
                win.addstr(0, 0, "Downloading...")
                e = delete(id, typ)
                win.clear()
                win.addstr(0, 0, e)
                win.getch()
                win.clear()

        if pointer == categories["Rename"]:
            
            win.clear()
            win.addstr(0, 0, "type \"back\" to go back")

            win.addstr(2, 0, "filename    : ")
            fro = raw_input(win, 2, 11, "")
            win.clear()

            if fro == "back":
                pass
            else:
                win.addstr(0, 0, "file type   : ")
                typ = raw_input(win, 0, 11, "")
                win.clear()
                win.addstr(0, 0, "new filename: ")
                to = raw_input(win, 0, 11, "")
                win.clear()
                win.clear()
                win.addstr(0, 0, "Downloading...")
                e = rename(fro, to, typ)
                win.clear()
                win.addstr(0, 0, e)
                win.getch()
                win.clear()

    


        if pointer == categories["Download"]:
            win.clear()
            win.addstr(0, 0, "type \"back\" to go back")

            win.addstr(2, 0, "file id  : ")
            id = raw_input(win, 2, 11, "")
            win.clear()

            if id == "back":
                pass
            else:
                win.addstr(0, 0, "file type: ")
                typ = raw_input(win, 0, 11, "")
                win.clear()
                win.clear()
                win.addstr(0, 0, "Downloading...")
                e = download(id, typ)
                win.clear()
                win.addstr(0, 0, e)
                win.getch()
                win.clear()


        pointer = 0
                
os.system("cls")